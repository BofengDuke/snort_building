<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/tr/html4/loose.dtd">
<html>
<head>
<title>LANMP一键安装包,集lamp,lnmp,lnamp,wdcp,wdos,wddns,wdcdn,云主机linux服务器管理系统面板软件</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="author" content="wdCP && WDlinux">
<meta name="keywords" content="LANMP一键安装包,集lamp,lnmp,lnamp,wdcp,wdos,wddns,wdcdn,云主机linux服务器管理系统面板软件">
<meta name="description" content="LANMP一键安装包,集lamp,lnmp,lnamp,wdcp,wdos,wddns,wdcdn,云主机linux服务器管理系统面板软件">
<link rel="shortcut icon" href="favicon.ico" type="image/ico">
<style type="text/css"> 
<!--
.links {color: #009900}
.STYLE1 {font-weight: bold}
-->
</style>
</head>
<body>
<br>
<br>
<center>
<strong>恭喜，lnmp 已安装成功!</strong><br>
<h1><img src="http://www.wdlinux.cn/images/lnmp.gif" alt="wdlinux_lnmp集成安装版"></h1>
<br>
<h2><A href="http://www.wdlinux.cn/bbs/forum-5-1.html" target="_blank" rel="nofollow">LANMP一键安装包</A>是一个基于CentOS/RadHat可以在vps/云主机/独立服务器上方便,快速安装的Shell脚本程序包</h2>
<h2>快速安装部署LANMP应用(Nginx、Apache、MySQL、PHP、phpMyAdmin)的WEB生产环境。</h2>
<p>wdCP管理面板 <a href="http://<?=$_SERVER["HTTP_HOST"];?>:8080" target=_blank>http://<?=$_SERVER["HTTP_HOST"];?>:8080</a> 默认用户密码:admin wdlinux.cn </p>
<p><span class="STYLE1">查看服务器WEB环境：</span><a href="/iProber2.php" target="_blank" class="links">探针信息</a>　<a href="/phpinfo.php" target="_blank" class="links">phpinfo信息</a></p>
<p>wdOS官网: <a href="http://www.wdos.net" target="_blank" rel="nofollow">http://www.wdos.net</a></p>
<p>wdCP管理系交流统论坛 <a href="http://www.wdlinux.cn/bbs/forum-23-1.html" target="_blank" rel="nofollow">http://www.wdlinux.cn/bbs/forum-23-1.html</a> </p>
<p>lanmp一键安装包： <a href="http://www.wdlinux.cn/bbs/forum-5-1.html" target="_blank" rel="nofollow">http://www.wdlinux.cn/bbs/forum-5-1.html</a></p>
<p>wdOS论坛讨论区： <a href="http://www.wdlinux.cn/bbs/forum-2-1.html" target="_blank" rel="nofollow">http://www.wdlinux.cn/bbs/forum-2-1.html</a></p>
<p>wddns免费智能DNS系统 <a href="http://www.wdlinux.cn/bbs/forum-18-1.html" target="_blank" rel="nofollow">http://www.wdlinux.cn/bbs/forum-18-1.html</a></p>
<p>wdcdn缓存加速管理系统 <a href="http://www.wdlinux.cn/bbs/forum-4-1.html" target="_blank" rel="nofollow">http://www.wdlinux.cn/bbs/forum-4-1.html</a> </p>
<p><a href="http://www.wddns.net" target="_blank" rel="nofollow">免费智能DNS解析,多线路多省份智能DNS解析</a> <a href="http://www.wdcdn.com" target="_blank" rel="nofollow">免费CDN加速,全国CDN加速</a></p>
<h3><a href="http://www.wdlinux.cn/bbs/forum-5-1.html" target="_blank" rel="nofollow">lanmp一键安装包</a> by <a href="http://www.wdlinux.cn" target="_blank" rel="nofollow">wdlinux</a> </h3>
<p>为安全起见,本页可删除或重命名</p>
</center>
</body>
</html>
